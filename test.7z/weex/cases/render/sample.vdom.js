({
  type: 'div',
  style: {
    justifyContent: 'center'
  },
  children: [{
    type: 'text',
    attr: {
      value: 'Yo'
    },
    classList: ['freestyle']
  }]
})
